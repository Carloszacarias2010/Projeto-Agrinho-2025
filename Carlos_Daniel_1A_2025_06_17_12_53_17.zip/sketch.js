let colheitadeira;
let trigos = [];
const NUM_TRIGOS_INICIAL = 50; // Quantidade de trigos no campo inicialmente
let score = 0; // Pontuação do jogador
const TRIGO_POR_VIAGEM = 10; // Quantidade de trigo para encher a colheitadeira
let estadoJogo = 'campo'; // Pode ser 'campo', 'transportando', 'entregue'

// Posição da farinheira (representando a cidade)
let farinheira = {
  x: 700,
  y: 50,
  largura: 80,
  altura: 80
};

let mostrarInstrucoes = true; // Variável para controlar a exibição das instruções

function setup() {
  createCanvas(800, 600); // Cria um canvas de 800x600 pixels

  // Inicializa a colheitadeira no centro inferior da tela
  colheitadeira = {
    x: width / 2,
    y: height - 50,
    largura: 60,
    altura: 80,
    velocidade: 3,
    rodasLargura: 15,
    rodasAltura: 20,
    ganchosLargura: 80,
    ganchosAltura: 15,
    colhendo: false, // Variável para controlar a animação de colheita
    trigoCarregado: 0 // Quantidade de trigo carregado na colheitadeira
  };

  // Cria os trigos iniciais
  gerarTrigos(NUM_TRIGOS_INICIAL);

  // Define um temporizador para esconder as instruções após alguns segundos
  setTimeout(() => {
    mostrarInstrucoes = false;
  }, 7000); // As instruções desaparecem após 7 segundos
}

function draw() {
  // --- Desenho do cenário baseado no estado do jogo ---
  if (estadoJogo === 'campo' || estadoJogo === 'transportando') {
    background(139, 69, 19); // Cor de terra para o campo
    // Desenha os trigos
    for (let i = 0; i < trigos.length; i++) {
      if (!trigos[i].colhido) {
        desenhaTrigo(trigos[i].x, trigos[i].y);
      }
    }
    desenhaFarinheiraCampo(); // Desenha a farinheira pequena no campo
  } else if (estadoJogo === 'entregue') {
    background(100, 150, 200); // Céu azul para a cidade
    desenhaFundoCidade(); // Desenha elementos da cidade
    desenhaBarracaoFarinheira(); // Desenha a farinheira grande (barracão)
  }

  // --- Lógica de desenho da colheitadeira e texto ---
  desenhaColheitadeira(); // Desenha a colheitadeira em ambos os cenários

  // Lógica do jogo baseada no estado
  if (estadoJogo === 'campo') {
    // Variável para detectar se alguma tecla de movimento foi pressionada
    let moved = false;

    // Movimento da colheitadeira com as teclas
    if (keyIsDown(87)) { // W - Frente
      colheitadeira.y -= colheitadeira.velocidade;
      moved = true;
    }
    if (keyIsDown(83)) { // S - Trás
      colheitadeira.y += colheitadeira.velocidade;
      moved = true;
    }
    if (keyIsDown(65)) { // A - Esquerda
      colheitadeira.x -= colheitadeira.velocidade;
      moved = true;
    }
    if (keyIsDown(68)) { // D - Direita
      colheitadeira.x += colheitadeira.velocidade;
      moved = true;
    }

    // Se a colheitadeira se moveu, esconde as instruções
    if (moved && mostrarInstrucoes) {
      mostrarInstrucoes = false;
    }

    // Limita a colheitadeira dentro da tela (evita que vá para fora no modo campo)
    colheitadeira.x = constrain(colheitadeira.x, colheitadeira.largura / 2, width - colheitadeira.largura / 2);
    colheitadeira.y = constrain(colheitadeira.y, colheitadeira.altura / 2, height - colheitadeira.altura / 2);

    verificarColheita();

    // Se a colheitadeira estiver cheia, muda para o estado de transporte
    if (colheitadeira.trigoCarregado >= TRIGO_POR_VIAGEM) {
      estadoJogo = 'transportando';
    }

  } else if (estadoJogo === 'transportando') {
    // Mover a colheitadeira em direção à farinheira pequena no canto
    let dirX = farinheira.x - colheitadeira.x;
    let dirY = farinheira.y - colheitadeira.y;
    let distancia = dist(colheitadeira.x, colheitadeira.y, farinheira.x, farinheira.y);

    if (distancia > colheitadeira.velocidade) {
      colheitadeira.x += dirX / distancia * colheitadeira.velocidade;
      colheitadeira.y += dirY / distancia * colheitadeira.velocidade;
    } else {
      // Chegou na farinheira (muda para o cenário da cidade e reposiciona a colheitadeira)
      estadoJogo = 'entregue';
      score += colheitadeira.trigoCarregado; // Adiciona os pontos ao score total
      colheitadeira.trigoCarregado = 0; // Zera o trigo carregado

      // Reposiciona a colheitadeira para a cidade
      colheitadeira.x = width / 2;
      colheitadeira.y = height - 100; // Posição para aparecer na frente do barracão

      gerarTrigos(NUM_TRIGOS_INICIAL); // Gera novos trigos no campo para a próxima rodada
      setTimeout(() => estadoJogo = 'campo', 4000); // Volta para o campo após 4 segundos (tempo para a mensagem)
    }
  } else if (estadoJogo === 'entregue') {
    // Exibe a mensagem de conexão campo-cidade
    fill(0, 150, 0); // Verde escuro
    textSize(32);
    textAlign(CENTER, CENTER);
    text("Que legal!", width / 2, height / 2 - 30);
    text("A conexão campo com a cidade!", width / 2, height / 2 + 10);
  }

  // Exibe a pontuação e o trigo carregado (visível em todos os estados, exceto quando a mensagem toma a tela)
  if (estadoJogo !== 'entregue') {
    fill(255); // Cor branca para o texto
    textSize(20);
    textAlign(LEFT, TOP);
    text("Pontuação: " + score, 10, 10);
    text("Trigo Carregado: " + colheitadeira.trigoCarregado + "/" + TRIGO_POR_VIAGEM, 10, 40);
  }

  // --- Exibe o letreiro de instruções se mostrarInstrucoes for verdadeiro ---
  if (mostrarInstrucoes && estadoJogo === 'campo') {
    fill(0, 0, 0, 180); // Fundo preto semi-transparente
    rect(width / 2 - 150, height / 2 - 60, 300, 100, 10); // Retângulo arredondado

    fill(255); // Texto branco
    textSize(20);
    textAlign(CENTER, CENTER);
    text("Use WASD para mover a colheitadeira!", width / 2, height / 2 - 10);
    textSize(14);
    text("(Colha " + TRIGO_POR_VIAGEM + " trigos para ir à cidade!)", width / 2, height / 2 + 20);
  }
}

function desenhaTrigo(x, y) {
  // Caule
  stroke(100, 70, 0); // Cor de marrom/verde para o caule
  strokeWeight(2);
  line(x, y, x, y + 20);

  // Grãos
  fill(255, 220, 0); // Cor amarela para os grãos
  noStroke();
  ellipse(x, y, 8, 12); // Desenha a "cabeça" do trigo
}

function desenhaColheitadeira() {
  push(); // Salva o estado atual das transformações
  translate(colheitadeira.x, colheitadeira.y); // Move o sistema de coordenadas para o centro da colheitadeira

  // Corpo da colheitadeira
  fill(200, 100, 0); // Cor laranja/vermelha
  rectMode(CENTER);
  rect(0, 0, colheitadeira.largura, colheitadeira.altura, 5); // Corpo arredondado

  // Cabine
  fill(100); // Cor cinza para a cabine
  rect(0, -colheitadeira.altura / 4, colheitadeira.largura * 0.7, colheitadeira.altura * 0.4);

  // Rodas
  fill(50); // Cor escura para as rodas
  ellipse(-colheitadeira.largura / 3, colheitadeira.altura / 2 - colheitadeira.rodasAltura / 2, colheitadeira.rodasLargura, colheitadeira.rodasAltura); // Roda esquerda
  ellipse(colheitadeira.largura / 3, colheitadeira.altura / 2 - colheitadeira.rodasAltura / 2, colheitadeira.rodasLargura, colheitadeira.rodasAltura); // Roda direita

  // Ganchos (parte de colheita)
  fill(150); // Cor cinza claro para os ganchos
  rect(0, colheitadeira.altura / 2 + colheitadeira.ganchosAltura / 2, colheitadeira.ganchosLargura, colheitadeira.ganchosAltura);

  // Animação de colheita
  if (colheitadeira.colhendo) {
    fill(255, 255, 0, 150); // Amarelo transparente
    ellipse(0, colheitadeira.altura / 2 + colheitadeira.ganchosAltura / 2, colheitadeira.ganchosLargura * 1.2, colheitadeira.ganchosAltura * 1.5);
  }

  pop(); // Restaura o estado anterior das transformações
}

function verificarColheita() {
  colheitadeira.colhendo = false; // Reseta o estado de colheita a cada frame

  for (let i = 0; i < trigos.length; i++) {
    // Só verifica se o trigo não foi colhido e se a colheitadeira não está cheia
    if (!trigos[i].colhido && colheitadeira.trigoCarregado < TRIGO_POR_VIAGEM) {
      // Calcula a distância entre o centro dos ganchos e o trigo
      let distX = abs(colheitadeira.x - trigos[i].x);
      let distY = abs((colheitadeira.y + colheitadeira.altura / 2 + colheitadeira.ganchosAltura / 2) - trigos[i].y);

      // Se o trigo estiver dentro da área dos ganchos, ele é colhido
      if (distX < colheitadeira.ganchosLargura / 2 && distY < colheitadeira.ganchosAltura / 2 + 10) {
        trigos[i].colhido = true;
        colheitadeira.colhendo = true; // Ativa a animação de colheita
        colheitadeira.trigoCarregado++; // Adiciona um trigo ao carregamento
      }
    }
  }
}

// --- Funções de Desenho de Cenário ---

function desenhaFarinheiraCampo() {
  fill(120, 80, 50); // Cor de madeira ou tijolo para a farinheira
  rect(farinheira.x - farinheira.largura / 2, farinheira.y - farinheira.altura / 2, farinheira.largura, farinheira.altura);

  fill(200); // Telhado cinza
  triangle(farinheira.x - farinheira.largura / 2, farinheira.y - farinheira.altura / 2,
           farinheira.x + farinheira.largura / 2, farinheira.y - farinheira.altura / 2,
           farinheira.x, farinheira.y - farinheira.altura / 2 - 30); // Telhado triangular

  fill(0); // Janela escura
  rect(farinheira.x - 10, farinheira.y, 20, 20);
}

function desenhaFundoCidade() {
  // Chão da cidade (asfalto/cimento)
  fill(80);
  rect(0, height * 0.7, width, height * 0.3);

  // Prédios simples
  fill(150, 150, 180); // Cor de prédio
  rect(50, height * 0.7 - 100, 80, 100);
  rect(180, height * 0.7 - 150, 100, 150);
  rect(width - 150, height * 0.7 - 80, 60, 80);
  rect(width - 250, height * 0.7 - 120, 70, 120);

  // Janelas
  fill(200, 200, 0); // Amarelo para janelas iluminadas
  rect(60, height * 0.7 - 90, 15, 15);
  rect(60, height * 0.7 - 60, 15, 15);
  rect(190, height * 0.7 - 140, 20, 20);
  rect(190, height * 0.7 - 100, 20, 20);
}

function desenhaBarracaoFarinheira() {
  // Centro da farinheira na cidade
  let bx = width / 2;
  let by = height / 2;
  let blargura = 200;
  let baltura = 180;

  // Corpo principal do barracão
  fill(150, 100, 50); // Cor de madeira ou tijolo envelhecido
  rect(bx - blargura / 2, by - baltura / 2, blargura, baltura);

  // Telhado
  fill(100); // Cinza escuro para o telhado
  triangle(bx - blargura / 2 - 20, by - baltura / 2,
           bx + blargura / 2 + 20, by - baltura / 2,
           bx, by - baltura / 2 - 80); // Telhado mais inclinado

  // Silo (opcional, para dar mais cara de farinheira)
  fill(180); // Prata para o silo
  ellipse(bx + blargura / 2 + 30, by, 60, 150);

  // Entrada/Porta
  fill(80, 40, 0); // Porta escura
  rect(bx - 30, by + baltura / 2 - 80, 60, 80);

  // Escrita "Farinheira"
  fill(255);
  textSize(24);
  textAlign(CENTER, CENTER);
  text("FARINHEIRA", bx, by - baltura / 2 + 20);
}


function gerarTrigos(quantidade) {
  trigos = []; // Limpa o array de trigos existentes
  for (let i = 0; i < quantidade; i++) {
    trigos.push({
      x: random(50, width - 50),
      y: random(50, height - 150), // Evita que o trigo nasça muito perto da colheitadeira inicial
      colhido: false // Se o trigo foi colhido
    });
  }
}